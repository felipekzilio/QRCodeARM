package com.example.qrcodeappluiz

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import com.google.zxing.integration.android.IntentIntegrator
import com.google.zxing.integration.android.IntentResult

//import kotlinx.android.synthetic.main.activity_main.*


@Suppress("DEPRECATION")
class MainActivity : AppCompatActivity() {
    var ResultadoQRCODE: String? = null
    var wv1: WebView? = null
    var url: String? = null
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        setContentView(R.layout.activity_main)
        val btn_leitura1: Button = findViewById(R.id.btn_leitura1)
        val btn_voltar: Button = findViewById(R.id.btn_voltar)

        btn_leitura1.setOnClickListener {
            val scanner = IntentIntegrator(this)
            scanner.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE)
            scanner.setBeepEnabled(true) //retira o beep ao scannear
            scanner.initiateScan() // `this` is the current Activity


        }



        btn_voltar.setOnClickListener {

            wv1?.isVisible =false;


        }

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)


        val btn_voltar: Button = findViewById(R.id.btn_voltar)

        if(resultCode == Activity.RESULT_OK){
            val result: IntentResult = IntentIntegrator.parseActivityResult(requestCode, resultCode, data)
            ResultadoQRCODE = result.contents;
            if (result != null) {
                if (result.contents == null) {
                    Toast.makeText(this, "Cancelado", Toast.LENGTH_LONG).show()
                } else {
                  //  Toast.makeText(this, "Resultado: " + result.contents, Toast.LENGTH_LONG)
                    Toast.makeText(this, "Resultado: " + ResultadoQRCODE, Toast.LENGTH_LONG)
                        .show()
                    url = "https://antihackpro.com/OLD/index.php?nm="+this.ResultadoQRCODE
                    if (ResultadoQRCODE != null) {
                        wv1 = findViewById<android.view.View?>(R.id.wv) as WebView?
                        wv1?.loadUrl(url!!)
                        wv1?.setWebViewClient(
                            object : WebViewClient() {
                                fun onPageStarted(view: WebView?, url: String?) {}
                                override fun onPageFinished(view: WebView, url: String) {
                                    super.onPageFinished(view, url)
                                }
                            })

                        wv1?.isVisible =true;
                        btn_voltar.isVisible =true;
                    }
                }
            } else {
                super.onActivityResult(requestCode, resultCode, data)
            }
        }


    }



}